DOMAIN = "solar_eclipse"
