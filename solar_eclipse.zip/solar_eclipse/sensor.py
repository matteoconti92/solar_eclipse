from datetime import datetime, timedelta, timezone
from homeassistant.components.sensor import SensorEntity
from .const import DOMAIN

# Skyfield optional
INSTALL_SKYFIELD = False
SKYFIELD_AVAILABLE = False

try:
    from skyfield.api import load, wgs84
    SKYFIELD_AVAILABLE = True
except ImportError:
    SKYFIELD_AVAILABLE = False

# Static dataset example
DATASET = [
    {
        "date": "2026-08-12T17:00:00Z",
        "type": "Total",
        "visibility": "Italy, Europe",
        "start": "2026-08-12T16:00:00Z",
        "maximum": "2026-08-12T17:45:00Z",
        "end": "2026-08-12T18:30:00Z",
        "magnitude": 0.65
    }
]


async def async_setup_entry(hass, entry, async_add_entities):
    install_skyfield = entry.data.get("install_skyfield", True)

    sensors = [
        NextEclipseSensor(hass, install_skyfield),
        EclipseCoverageSensor(hass, install_skyfield),
        EclipseTypeSensor(hass, install_skyfield),
        EclipseVisibilitySensor(hass, install_skyfield),
        EclipseStartSensor(hass, install_skyfield),
        EclipseMaxSensor(hass, install_skyfield),
        EclipseEndSensor(hass, install_skyfield),
    ]
    async_add_entities(sensors, True)


class BaseEclipseSensor(SensorEntity):
    def __init__(self, hass, install_skyfield):
        self._hass = hass
        self._install_skyfield = install_skyfield
        self._attr_should_poll = True
        self._attr_native_value = None

    @property
    def available(self):
        if self._install_skyfield and not SKYFIELD_AVAILABLE:
            return False
        return True


def get_next_eclipse():
    now = datetime.now(timezone.utc)
    future = [e for e in DATASET if datetime.fromisoformat(e["date"].replace("Z","+00:00")) > now]
    if not future:
        return None
    return sorted(future, key=lambda e: datetime.fromisoformat(e["date"].replace("Z","+00:00")))[0]


class NextEclipseSensor(BaseEclipseSensor):
    _attr_name = "Next Solar Eclipse"
    _attr_unique_id = "next_eclipse"

    async def async_update(self):
        eclipse = get_next_eclipse()
        self._attr_native_value = eclipse["date"] if eclipse else None


class EclipseCoverageSensor(BaseEclipseSensor):
    _attr_name = "Solar Eclipse Coverage (%)"
    _attr_unique_id = "eclipse_coverage"
    _attr_native_unit_of_measurement = "%"
    _attr_update_interval = timedelta(hours=24)  # update every 24h

    async def async_update(self):
        eclipse = get_next_eclipse()
        if not eclipse:
            self._attr_native_value = None
            return

        if self._install_skyfield and SKYFIELD_AVAILABLE:
            # TODO: calculate real coverage using Skyfield
            self._attr_native_value = round(eclipse["magnitude"] * 100, 1)
        else:
            self._attr_native_value = None


class EclipseTypeSensor(BaseEclipseSensor):
    _attr_name = "Solar Eclipse Type"
    _attr_unique_id = "eclipse_type"

    async def async_update(self):
        eclipse = get_next_eclipse()
        self._attr_native_value = eclipse["type"] if eclipse else None


class EclipseVisibilitySensor(BaseEclipseSensor):
    _attr_name = "Solar Eclipse Visibility"
    _attr_unique_id = "eclipse_visibility"

    async def async_update(self):
        eclipse = get_next_eclipse()
        self._attr_native_value = eclipse["visibility"] if eclipse else None


class EclipseStartSensor(BaseEclipseSensor):
    _attr_name = "Solar Eclipse Start"
    _attr_unique_id = "eclipse_start"

    async def async_update(self):
        eclipse = get_next_eclipse()
        self._attr_native_value = eclipse["start"] if eclipse else None


class EclipseMaxSensor(BaseEclipseSensor):
    _attr_name = "Solar Eclipse Maximum"
    _attr_unique_id = "eclipse_max"

    async def async_update(self):
        eclipse = get_next_eclipse()
        self._attr_native_value = eclipse["maximum"] if eclipse else None


class EclipseEndSensor(BaseEclipseSensor):
    _attr_name = "Solar Eclipse End"
    _attr_unique_id = "eclipse_end"

    async def async_update(self):
        eclipse = get_next_eclipse()
        self._attr_native_value = eclipse["end"] if eclipse else None
